"""Start the PySide6 desktop app:  python gui.py"""
import sys

from PySide6.QtWidgets import QApplication

from ui.theme import STYLE
from ui.window import App


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")          # same look on Windows, macOS and Linux
    app.setStyleSheet(STYLE)
    window = App()
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
