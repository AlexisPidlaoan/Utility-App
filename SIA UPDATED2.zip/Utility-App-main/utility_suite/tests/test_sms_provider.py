"""Tests for real SMS sending. A tiny local server stands in for Twilio, so nothing leaves this computer.

    python -m unittest discover -s tests -v
"""
import base64
import json
import os
import sqlite3
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import sms_provider  # noqa: E402
from app import create_app  # noqa: E402
from database import init_db  # noqa: E402

SID, TOKEN = "AC" + "1" * 32, "secret-token"


class FakeTwilio(BaseHTTPRequestHandler):
    calls = []                  # (method, path, form, authorization header)
    next_status = "queued"      # status the fake reports for new messages
    lookup_status = "delivered"  # status the fake reports on GET

    def log_message(self, *_args):
        pass

    def _reply(self, code, body):
        raw = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        form = parse_qs(self.rfile.read(int(self.headers["Content-Length"])).decode())
        form = {k: v[0] for k, v in form.items()}
        FakeTwilio.calls.append(("POST", self.path, form, self.headers.get("Authorization")))
        if form.get("To", "").endswith("9999"):
            return self._reply(400, {"code": 21211, "message": "Invalid 'To' Phone Number"})
        if self.headers.get("Authorization") != "Basic " + base64.b64encode(f"{SID}:{TOKEN}".encode()).decode():
            return self._reply(401, {"code": 20003, "message": "Authenticate"})
        self._reply(201, {"sid": "SM" + "a" * 32, "status": FakeTwilio.next_status})

    def do_GET(self):
        FakeTwilio.calls.append(("GET", self.path, None, self.headers.get("Authorization")))
        self._reply(200, {"sid": "SM" + "a" * 32, "status": FakeTwilio.lookup_status})


class SmsProviderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = HTTPServer(("127.0.0.1", 0), FakeTwilio)
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.tmp = tempfile.mkdtemp()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def setUp(self):
        FakeTwilio.calls.clear()
        FakeTwilio.next_status, FakeTwilio.lookup_status = "queued", "delivered"
        self.saved = dict(os.environ)
        for name in sms_provider.ENV_NAMES.values():
            os.environ.pop(name, None)
        os.environ["SMS_SETTINGS_FILE"] = os.path.join(self.tmp, "sms_settings.json")
        os.environ["TWILIO_API_BASE"] = f"http://127.0.0.1:{self.server.server_port}"
        sms_provider.clear_settings()

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self.saved)

    def configure(self):
        sms_provider.save_settings({"account_sid": SID, "auth_token": TOKEN, "from_number": "+15005550006"})

    # ----- settings -----
    def test_not_configured_by_default(self):
        self.assertFalse(sms_provider.is_configured())
        self.assertEqual(sms_provider.send_sms("+639171234567", "hi").status, "failed")
        self.assertEqual(FakeTwilio.calls, [])

    def test_settings_file_is_private_and_env_overrides_it(self):
        self.configure()
        self.assertTrue(sms_provider.is_configured())
        if os.name == "posix":
            self.assertEqual(os.stat(sms_provider.settings_path()).st_mode & 0o777, 0o600)
        os.environ["TWILIO_FROM_NUMBER"] = "+15005550001"
        self.assertEqual(sms_provider.load_settings()["from_number"], "+15005550001")

    def test_messaging_service_can_replace_from_number(self):
        sms_provider.save_settings({"account_sid": SID, "auth_token": TOKEN, "messaging_service_sid": "MG" + "2" * 32})
        sms_provider.send_sms("+639171234567", "hi")
        self.assertEqual(FakeTwilio.calls[0][2]["MessagingServiceSid"], "MG" + "2" * 32)
        self.assertNotIn("From", FakeTwilio.calls[0][2])

    # ----- sending -----
    def test_send_posts_to_number_with_body_and_auth(self):
        self.configure()
        result = sms_provider.send_sms("+639171234567", "Hello there")
        self.assertEqual((result.status, result.reason), ("sent", None))
        self.assertTrue(result.provider_id.startswith("SM"))
        method, path, form, auth = FakeTwilio.calls[0]
        self.assertEqual(path, f"/2010-04-01/Accounts/{SID}/Messages.json")
        self.assertEqual(form, {"To": "+639171234567", "Body": "Hello there", "From": "+15005550006"})
        self.assertTrue(auth.startswith("Basic "))

    def test_twilio_error_becomes_failed_with_reason(self):
        self.configure()
        result = sms_provider.send_sms("+639170009999", "x")
        self.assertEqual(result.status, "failed")
        self.assertIn("21211", result.reason)

    def test_wrong_credentials_give_a_clear_reason_and_no_token_leak(self):
        sms_provider.save_settings({"account_sid": SID, "auth_token": "wrong", "from_number": "+15005550006"})
        result = sms_provider.send_sms("+639171234567", "x")
        self.assertEqual(result.status, "failed")
        self.assertIn("Auth Token", result.reason)
        self.assertNotIn("wrong", result.reason)

    def test_network_error_is_a_failed_result_not_an_exception(self):
        self.configure()
        os.environ["TWILIO_API_BASE"] = "http://127.0.0.1:9"           # nothing listens here
        result = sms_provider.send_sms("+639171234567", "x")
        self.assertEqual(result.status, "failed")
        self.assertIn("Network error", result.reason)


class DispatchTests(unittest.TestCase):
    """dispatch_message / refresh_statuses against a real SQLite file."""

    @classmethod
    def setUpClass(cls):
        SmsProviderTests.setUpClass.__func__(cls)
        cls.path = os.path.join(cls.tmp, "t.db")
        init_db(cls.path)

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def setUp(self):
        SmsProviderTests.setUp(self)
        self.db = sqlite3.connect(self.path)
        self.db.row_factory = sqlite3.Row
        self.db.execute("INSERT OR IGNORE INTO users (id, username, password_hash) VALUES (1, 'u', 'x')")
        self.db.commit()

    def tearDown(self):
        self.db.close()
        SmsProviderTests.tearDown(self)

    configure = SmsProviderTests.configure

    def row(self):
        return self.db.execute("SELECT * FROM message_logs ORDER BY id DESC LIMIT 1").fetchone()

    def test_unconfigured_uses_simulator(self):
        from routes import messaging
        messaging.dispatch_message(self.db, 1, "+639170000000", "hi")
        self.assertEqual((self.row()["provider"], self.row()["status"]), ("simulated", "failed"))
        self.assertEqual(FakeTwilio.calls, [])

    def test_configured_single_send_is_real_and_logged(self):
        from routes import messaging
        self.configure()
        status, reason = messaging.dispatch_message(self.db, 1, "+639171234567", "hi")
        self.assertEqual((status, reason), ("sent", None))
        row = self.row()
        self.assertEqual((row["provider"], row["status"]), ("twilio", "sent"))
        self.assertTrue(row["provider_id"].startswith("SM"))
        self.assertIsNotNone(row["sent_at"])
        self.assertIsNone(row["finished_at"])

    def test_failed_real_send_is_logged_with_reason(self):
        from routes import messaging
        self.configure()
        messaging.dispatch_message(self.db, 1, "+639170009999", "hi")
        row = self.row()
        self.assertEqual(row["status"], "failed")
        self.assertIn("21211", row["failure_reason"])

    def test_bulk_style_sends_never_reach_twilio(self):
        from routes import messaging
        self.configure()
        messaging.dispatch_message(self.db, 1, "+639171234567", "hi", live=False)
        self.assertEqual(FakeTwilio.calls, [])
        self.assertEqual(self.row()["provider"], "simulated")

    def test_refresh_updates_sent_messages_to_delivered(self):
        from routes import messaging
        self.configure()
        messaging.dispatch_message(self.db, 1, "+639171234567", "hi")
        self.assertEqual(messaging.refresh_statuses(self.db, 1), 1)
        row = self.row()
        self.assertEqual(row["status"], "delivered")
        self.assertIsNotNone(row["finished_at"])
        self.assertEqual(messaging.refresh_statuses(self.db, 1), 0)     # nothing left to check

    def test_old_database_gets_provider_columns(self):
        old = os.path.join(self.tmp, "old.db")
        conn = sqlite3.connect(old)
        conn.executescript("""
            CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, password_hash TEXT);
            CREATE TABLE message_logs (id INTEGER PRIMARY KEY, user_id INTEGER, recipient TEXT,
                message_body TEXT, segments INTEGER, status TEXT, failure_reason TEXT,
                queued_at TIMESTAMP, sent_at TIMESTAMP, finished_at TIMESTAMP);
            INSERT INTO message_logs (user_id, recipient, message_body, segments, status)
                VALUES (1, '+639171234567', 'old', 1, 'delivered');""")
        conn.commit()
        conn.close()
        init_db(old)
        conn = sqlite3.connect(old)
        self.assertEqual(conn.execute("SELECT provider, provider_id FROM message_logs").fetchone(),
                         ("simulated", None))
        conn.close()


class RouteTests(unittest.TestCase):
    def test_send_route_reports_provider_and_refresh_needs_config(self):
        os.environ["SMS_SETTINGS_FILE"] = os.path.join(tempfile.mkdtemp(), "none.json")
        for name in sms_provider.ENV_NAMES.values():
            os.environ.pop(name, None)
        app = create_app({"DATABASE": os.path.join(tempfile.mkdtemp(), "r.db"),
                          "SECRET_KEY": "k", "TESTING": True})
        c = app.test_client()
        c.post("/api/register", json={"username": "routeuser", "password": "correct horse battery"})
        res = c.post("/api/messages/send", json={"recipient": "09171234567", "message": "hi"})
        self.assertEqual(res.get_json()["provider"], "simulated")
        self.assertEqual(c.post("/api/messages/refresh").status_code, 400)


if __name__ == "__main__":
    unittest.main()
