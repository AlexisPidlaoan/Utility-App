"""Dialog for the Twilio credentials that turn on real SMS sending."""
import sms_provider
from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QFormLayout, QLabel, QLineEdit, QMessageBox,
                               QPushButton, QVBoxLayout)

FIELDS = (("account_sid", "Account SID", "ACxxxxxxxx..."),
          ("auth_token", "Auth Token", ""),
          ("from_number", "From number", "+15551234567 (your Twilio number)"),
          ("messaging_service_sid", "Messaging Service SID", "optional, MGxxxx... (used instead of From number)"))


class SmsSettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("SMS settings (Twilio)")
        self.setMinimumWidth(480)
        current = sms_provider.load_settings()

        intro = QLabel("Enter your Twilio credentials to send real text messages.\n"
                       "They are saved on this computer in sms_settings.json (owner-only file).\n"
                       "Leave them empty to keep using the simulator. Environment variables "
                       "(TWILIO_ACCOUNT_SID, ...) take priority over this file.")
        intro.setWordWrap(True)

        form = QFormLayout()
        self.edits = {}
        for key, label, hint in FIELDS:
            edit = QLineEdit(current[key])
            edit.setPlaceholderText(hint)
            if key == "auth_token":
                edit.setEchoMode(QLineEdit.Password)
            self.edits[key] = edit
            form.addRow(label, edit)

        clear = QPushButton("Remove saved settings")
        clear.clicked.connect(self.clear)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(intro)
        layout.addLayout(form)
        layout.addWidget(clear)
        layout.addWidget(buttons)

    def save(self):
        values = {key: edit.text().strip() for key, edit in self.edits.items()}
        if any(values.values()) and not sms_provider.is_configured(values):
            QMessageBox.warning(self, "Incomplete settings",
                                "Real SMS needs the Account SID, the Auth Token, and either a "
                                "From number or a Messaging Service SID.")
            return
        sms_provider.save_settings(values)
        self.accept()

    def clear(self):
        sms_provider.clear_settings()
        for edit in self.edits.values():
            edit.clear()
