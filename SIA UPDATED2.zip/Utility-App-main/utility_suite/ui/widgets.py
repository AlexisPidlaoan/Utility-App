"""Small reusable Qt helpers shared by the tabs."""
from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import QAbstractItemView, QTableWidget, QTableWidgetItem

from .db import connect


def make_table(columns, widths):
    """A read-only, row-selecting table. `columns` is a list of (key, heading) pairs."""
    table = QTableWidget(0, len(columns))
    table.setHorizontalHeaderLabels([heading for _key, heading in columns])
    for index, width in enumerate(widths):
        table.setColumnWidth(index, width)
    table.setEditTriggers(QAbstractItemView.NoEditTriggers)
    table.setSelectionBehavior(QAbstractItemView.SelectRows)
    table.setSelectionMode(QAbstractItemView.SingleSelection)
    table.verticalHeader().setVisible(False)
    table.setShowGrid(False)
    table.setAlternatingRowColors(True)
    table.verticalHeader().setDefaultSectionSize(30)
    table.horizontalHeader().setStretchLastSection(True)
    return table


def fill_table(table, rows):
    """Replace the table's rows. Cells are stored as text, so a code like "007123" stays "007123"."""
    table.setRowCount(0)
    table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        for c, value in enumerate(row):
            table.setItem(r, c, QTableWidgetItem("" if value is None else str(value)))


def set_columns(table, columns, widths):
    """Change which columns the table shows. `widths` maps column key -> pixel width.

    Used by the Fake Data tab, whose columns depend on which fields the stored records contain.
    """
    table.setRowCount(0)
    table.setColumnCount(len(columns))
    table.setHorizontalHeaderLabels([heading for _key, heading in columns])
    for index, (key, _heading) in enumerate(columns):
        table.setColumnWidth(index, widths.get(key, 120))


def selected_text(table, column=0):
    """Text of `column` in the selected row, or None if no row is selected."""
    row = table.currentRow()
    if row < 0 or table.item(row, column) is None:
        return None
    return table.item(row, column).text()


class Worker(QThread):
    """Run `job(db)` on a background thread so a slow network call never freezes the window.

    SQLite connections cannot be shared between threads, so the job gets its own connection.
    The job's return value arrives through `done`; an exception arrives through `failed`.
    """
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, job, parent=None):
        super().__init__(parent)
        self.job = job

    def run(self):
        db = None
        try:
            db = connect()
            result = self.job(db)
            db.commit()
            self.done.emit(result)
        except Exception as exc:                    # shown to the user, not swallowed
            if db is not None:
                db.rollback()
            self.failed.emit(str(exc))
        finally:
            if db is not None:
                db.close()
