"""The application window: starts the services, then swaps between the login and main screens."""
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QMainWindow, QMessageBox

from . import settings
from .db import connect
from .login import LoginWidget
from .main_frame import MainWidget
from .server import start_redirect_server


class App(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(settings.WINDOW_TITLE)
        self.resize(*settings.WINDOW_SIZE)
        self.setMinimumSize(*settings.MIN_SIZE)
        self.server = start_redirect_server()
        self.db = connect()
        self.current = None
        self.show_login()
        if self.server is None:
            # Shown after the window is up, so the message box has a visible parent.
            QTimer.singleShot(0, lambda: QMessageBox.warning(
                self, "Redirect server not started",
                f"Port {settings.PORT} is busy, so short links will not open in a browser.\n"
                "Everything else still works."))

    def _swap(self, widget):
        old = self.current
        if old is not None and hasattr(old, "shutdown"):
            old.shutdown()                  # waits for any running background send
        self.current = widget
        self.setCentralWidget(widget)       # Qt deletes the previous central widget

    def show_login(self):
        self._swap(LoginWidget(self.db, self.show_main))

    def show_main(self, user_id, username):
        self._swap(MainWidget(self.db, user_id, username, self.show_login))

    def closeEvent(self, event):
        if self.current is not None and hasattr(self.current, "shutdown"):
            self.current.shutdown()
        if self.server is not None:
            self.server.shutdown()
        self.db.close()
        super().closeEvent(event)
