"""One minimal look for the whole app: light, neutral greys, a single blue accent.

Applied once in gui.py. Widgets opt in with an object name or a property:
    setObjectName("title" | "heading" | "muted" | "error")
    setProperty("primary", True)       -> the filled blue button for the main action of a screen
"""

BG, SURFACE, BORDER = "#fafafa", "#ffffff", "#e4e4e7"
TEXT, MUTED = "#18181b", "#71717a"
ACCENT, ACCENT_HOVER, DANGER = "#2563eb", "#1d4ed8", "#b91c1c"

STYLE = f"""
* {{ font-size: 13px; }}
QWidget {{ background: {BG}; color: {TEXT}; }}
QDialog, QMessageBox {{ background: {BG}; }}
QLabel {{ background: transparent; }}
QLabel#title {{ font-size: 26px; font-weight: 600; }}
QLabel#heading {{ font-weight: 600; }}
QLabel#muted {{ color: {MUTED}; }}
QLabel#error {{ color: {DANGER}; }}

QLineEdit, QPlainTextEdit, QSpinBox, QComboBox {{
    background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 6px; padding: 6px 8px;
    selection-background-color: {ACCENT}; selection-color: white;
}}
QLineEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QComboBox:focus {{ border: 1px solid {ACCENT}; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{
    background: {SURFACE}; border: 1px solid {BORDER}; selection-background-color: {ACCENT};
    selection-color: white; outline: 0;
}}

QPushButton {{
    background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 6px; padding: 6px 14px;
}}
QPushButton:hover {{ border-color: {MUTED}; }}
QPushButton:pressed {{ background: {BG}; }}
QPushButton:disabled {{ color: {MUTED}; background: {BG}; }}
QPushButton[primary="true"] {{ background: {ACCENT}; border: 1px solid {ACCENT}; color: white; }}
QPushButton[primary="true"]:hover {{ background: {ACCENT_HOVER}; border-color: {ACCENT_HOVER}; }}
QPushButton[primary="true"]:disabled {{ background: #93b4f5; border-color: #93b4f5; color: white; }}

QTabWidget::pane {{ border: none; border-top: 1px solid {BORDER}; }}
QTabBar {{ background: {BG}; }}
QTabBar::tab {{
    background: transparent; color: {MUTED}; padding: 9px 16px; border: none;
    border-bottom: 2px solid transparent; margin-right: 4px;
}}
QTabBar::tab:hover {{ color: {TEXT}; }}
QTabBar::tab:selected {{ color: {TEXT}; border-bottom: 2px solid {ACCENT}; }}

QTableWidget {{
    background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 6px; gridline-color: {BORDER};
    selection-background-color: #e8effd; selection-color: {TEXT}; alternate-background-color: {BG};
}}
QTableWidget::item {{ padding: 4px 6px; border: none; }}
QHeaderView::section {{
    background: {SURFACE}; color: {MUTED}; border: none; border-bottom: 1px solid {BORDER};
    padding: 6px 8px; font-weight: 600;
}}

QGroupBox {{
    background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 8px; margin-top: 12px;
    padding: 12px 8px 8px 8px;
}}
QGroupBox::title {{ subcontrol-origin: margin; left: 12px; padding: 0 4px; color: {MUTED}; background: {BG}; }}
QCheckBox {{ background: transparent; spacing: 6px; }}

QScrollBar:vertical {{ background: transparent; width: 10px; margin: 0; }}
QScrollBar::handle:vertical {{ background: {BORDER}; border-radius: 5px; min-height: 24px; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 0; }}
QScrollBar::handle:horizontal {{ background: {BORDER}; border-radius: 5px; min-width: 24px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}
"""
