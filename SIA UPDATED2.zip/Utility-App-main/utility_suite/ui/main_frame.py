"""The window shown after login: a header (user, totals, log out) and one tab per tool."""
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QTabWidget, QVBoxLayout, QWidget

from .tabs.fake_data import FakeDataTab
from .tabs.shortener import ShortenerTab
from .tabs.sms import SmsTab


class MainWidget(QWidget):
    STATS = (("Links", "SELECT COUNT(*) FROM urls WHERE user_id = ?"),
             ("Clicks", "SELECT COALESCE(SUM(clicks), 0) FROM urls WHERE user_id = ?"),
             ("Records", "SELECT COUNT(*) FROM fake_records WHERE user_id = ?"),
             ("Messages", "SELECT COUNT(*) FROM message_logs WHERE user_id = ?"))

    def __init__(self, db, user_id, username, on_logout, parent=None):
        super().__init__(parent)
        self.db, self.user_id = db, user_id

        who = QLabel(f"Signed in as {username}")
        who.setObjectName("heading")
        self.summary = QLabel()
        self.summary.setObjectName("muted")
        logout = QPushButton("Log out")
        logout.clicked.connect(on_logout)
        bar = QHBoxLayout()
        bar.addWidget(who)
        bar.addStretch()
        bar.addWidget(self.summary)
        bar.addSpacing(16)
        bar.addWidget(logout)

        self.tabs = QTabWidget()
        self.shortener = ShortenerTab(db, user_id, self.update_summary)
        self.fake = FakeDataTab(db, user_id, self.update_summary)
        self.sms = SmsTab(db, user_id, self.update_summary)
        self.tabs.addTab(self.shortener, "URL Shortener")
        self.tabs.addTab(self.fake, "Fake Data")
        self.tabs.addTab(self.sms, "SMS && Messaging")        # "&&" shows a literal "&" in Qt
        self.tabs.currentChanged.connect(lambda _i: self.refresh_all())

        layout = QVBoxLayout(self)
        layout.addLayout(bar)
        layout.addWidget(self.tabs)
        self.update_summary()

    def update_summary(self):
        counts = [f"{name}: {self.db.execute(sql, (self.user_id,)).fetchone()[0]}"
                  for name, sql in self.STATS]
        self.summary.setText("   ".join(counts))

    def refresh_all(self):
        # Bulk send needs the latest records and a browser visit changes click counts.
        self.shortener.refresh()
        self.update_summary()

    def shutdown(self):
        for tab in (self.shortener, self.fake, self.sms):
            tab.shutdown()
