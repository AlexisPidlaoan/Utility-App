"""3B.3  Fake Data tab: pick up to 16 fields, generate records, store them in SQLite, export CSV/JSON."""
import uuid

from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QGridLayout, QGroupBox, QHBoxLayout,
                               QLabel, QMessageBox, QPushButton, QSpinBox, QVBoxLayout)

from routes import fake_data as fd

from ..widgets import fill_table, make_table, set_columns
from .base import BaseTab

PICKER_COLUMNS = 4                      # checkboxes per row (16 fields -> 4 rows)
COLUMN_WIDTHS = {
    "first_name": 100, "last_name": 100, "full_name": 160, "sex": 60, "birthdate": 90, "age": 45,
    "civil_status": 90, "address": 260, "city": 110, "zip_code": 70, "country": 110,
    "mobile_number": 130, "email": 190, "username": 120, "job": 150, "company": 150,
}


class FakeDataTab(BaseTab):
    def __init__(self, db, user_id, on_change, parent=None):
        super().__init__(db, user_id, on_change, parent)
        self.count = QSpinBox()
        self.count.setRange(1, fd.MAX_RECORDS)
        self.count.setValue(10)
        self.locale = QComboBox()
        self.locale.addItems(list(fd.LOCALES))
        self.locale.setCurrentText("en_PH")
        self.total = QLabel()
        self.picked_text = QLabel()

        generate = QPushButton("Generate and save")
        generate.setProperty("primary", True)
        generate.clicked.connect(self.generate)
        csv_btn, json_btn, clear = QPushButton("Export CSV"), QPushButton("Export JSON"), QPushButton("Clear all")
        csv_btn.clicked.connect(lambda: self.export("csv"))
        json_btn.clicked.connect(lambda: self.export("json"))
        clear.clicked.connect(self.clear)

        top = QHBoxLayout()
        top.addWidget(QLabel("Records"))
        top.addWidget(self.count)
        top.addSpacing(12)
        top.addWidget(QLabel("Locale"))
        top.addWidget(self.locale)
        top.addSpacing(10)
        for button in (generate, csv_btn, json_btn, clear):
            top.addWidget(button)
        top.addStretch()
        top.addWidget(self.total)

        self.table = make_table([], [])

        layout = QVBoxLayout(self)
        layout.addLayout(top)
        layout.addWidget(self._build_picker())
        layout.addWidget(self.table, 1)
        self.update_picked_text()
        self.refresh()

    # ----- choosing fields -----
    def _build_picker(self):
        box = QGroupBox("Fields to generate")
        grid = QGridLayout(box)
        self.picked = {}                                    # field -> its checkbox
        for index, field in enumerate(fd.FIELDS):
            check = QCheckBox(fd.FIELD_LABELS[field])
            check.setChecked(True)
            check.toggled.connect(self.update_picked_text)
            self.picked[field] = check
            grid.addWidget(check, index // PICKER_COLUMNS, index % PICKER_COLUMNS)

        select_all, clear_sel = QPushButton("Select all"), QPushButton("Clear selection")
        select_all.clicked.connect(lambda: self.set_all(True))
        clear_sel.clicked.connect(lambda: self.set_all(False))
        bar = QHBoxLayout()
        bar.addWidget(select_all)
        bar.addWidget(clear_sel)
        bar.addWidget(self.picked_text)
        bar.addStretch()
        grid.addLayout(bar, (len(fd.FIELDS) - 1) // PICKER_COLUMNS + 1, 0, 1, PICKER_COLUMNS)
        return box

    def chosen_fields(self):
        return [f for f in fd.FIELDS if self.picked[f].isChecked()]

    def set_all(self, ticked):
        for check in self.picked.values():
            check.setChecked(ticked)

    def update_picked_text(self, *_args):
        self.picked_text.setText(f"{len(self.chosen_fields())} of {fd.MAX_FIELDS} fields selected")

    # ----- actions -----
    def generate(self):
        count = self.count.value()                          # the spin box already enforces 1..MAX
        fields, problem = fd.parse_fields(self.chosen_fields())
        if problem:
            QMessageBox.critical(self, "Choose fields", problem)
            return
        locale = self.locale.currentText()
        fk = fd.get_faker(locale)
        records = [fd.make_record(fk, locale, fields) for _ in range(count)]
        fd._save_records(self.db, self.user_id, uuid.uuid4().hex[:8], records, fields)
        self.refresh()
        self.on_change()

    def refresh(self):
        total = self.db.execute("SELECT COUNT(*) FROM fake_records WHERE user_id = ?",
                                (self.user_id,)).fetchone()[0]
        rows = self.db.execute(
            f"SELECT {', '.join(fd.FIELDS)} FROM fake_records WHERE user_id = ? "
            f"ORDER BY id DESC LIMIT {fd.LIST_LIMIT}", (self.user_id,)).fetchall()
        columns = fd.used_fields(rows)              # show only the columns that hold data
        set_columns(self.table, [(f, fd.FIELD_LABELS[f]) for f in columns], COLUMN_WIDTHS)
        fill_table(self.table, [[r[f] for f in columns] for r in rows])
        self.total.setText(f"{total} stored (showing latest {min(total, fd.LIST_LIMIT)})")

    def export(self, fmt):
        rows = self.db.execute(
            f"SELECT {', '.join(fd.FIELDS)} FROM fake_records WHERE user_id = ? ORDER BY id",
            (self.user_id,)).fetchall()
        if not rows:
            QMessageBox.information(self, "Nothing to export", "Generate some records first.")
            return
        path, _filter = QFileDialog.getSaveFileName(
            self, "Export records", f"fake_records.{fmt}", f"{fmt.upper()} files (*.{fmt})")
        if path:
            with open(path, "w", encoding="utf-8", newline="") as f:
                f.write(fd.EXPORT_FORMATS[fmt][0](rows))
            QMessageBox.information(self, "Exported", f"Saved {len(rows)} records to\n{path}")

    def clear(self):
        if QMessageBox.question(self, "Clear records",
                                "Delete all your stored fake records?") == QMessageBox.Yes:
            self.db.execute("DELETE FROM fake_records WHERE user_id = ?", (self.user_id,))
            self.db.commit()
            self.refresh()
            self.on_change()
