"""3B.1  URL Shortener tab: create short links, copy/open them, view click stats, delete."""
from PySide6.QtCore import QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QGuiApplication
from PySide6.QtWidgets import (QComboBox, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QPushButton, QVBoxLayout)

from routes import shortener as sh

from ..settings import BASE_URL
from ..widgets import fill_table, make_table, selected_text
from .base import BaseTab


class ShortenerTab(BaseTab):
    def __init__(self, db, user_id, on_change, parent=None):
        super().__init__(db, user_id, on_change, parent)
        self.url = QLineEdit()
        self.alias = QLineEdit()
        self.mode = QComboBox()
        self.mode.addItems(list(sh.CODE_MODES))
        shorten_btn = QPushButton("Shorten")
        shorten_btn.setProperty("primary", True)
        shorten_btn.clicked.connect(self.shorten)
        self.url.returnPressed.connect(self.shorten)

        form = QGridLayout()
        form.addWidget(QLabel("Long URL"), 0, 0)
        form.addWidget(self.url, 0, 1, 1, 4)
        form.addWidget(QLabel("Custom alias (optional)"), 1, 0)
        form.addWidget(self.alias, 1, 1)
        form.addWidget(QLabel("Code type"), 1, 2)
        form.addWidget(self.mode, 1, 3)
        form.addWidget(shorten_btn, 1, 4)
        form.setColumnStretch(1, 1)

        columns = [("code", "Short code"), ("short", "Short URL"), ("original", "Original URL"),
                   ("clicks", "Clicks"), ("created", "Created")]
        self.table = make_table(columns, [90, 190, 300, 60, 140])

        buttons = QHBoxLayout()
        for label, command in (("Copy short URL", self.copy), ("Open in browser", self.open_link),
                               ("Stats", self.stats), ("Delete", self.delete),
                               ("Refresh", self.refresh)):
            button = QPushButton(label)
            button.clicked.connect(command)
            buttons.addWidget(button)
        buttons.addStretch()

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(self.table, 1)
        layout.addLayout(buttons)
        self.refresh()

    def shorten(self):
        url, alias, mode = self.url.text().strip(), self.alias.text().strip(), self.mode.currentText()
        if not sh.is_valid_url(url):
            QMessageBox.critical(self, "Invalid URL", "Enter a valid http:// or https:// URL")
            return
        if alias:
            problem = sh.validate_alias(alias)
            if problem:
                QMessageBox.critical(self, "Invalid alias", problem)
                return
            code = sh.create_with_alias(self.db, self.user_id, url, alias)
            if code is None:
                self.db.rollback()          # a failed insert leaves a transaction open; the redirect
                                            # server in the background needs the database free
                QMessageBox.critical(self, "Alias in use", "Custom alias already in use")
                return
        elif mode == "random":
            code = sh.create_with_random_code(self.db, self.user_id, url)
            if code is None:
                self.db.rollback()
                QMessageBox.critical(self, "Error", "Could not generate a unique code, try again")
                return
        else:
            code = sh.create_with_base62_code(self.db, self.user_id, url)
        self.url.clear()
        self.alias.clear()
        self.refresh()
        self.on_change()
        QMessageBox.information(self, "Short link created", f"{BASE_URL}/{code}")

    def refresh(self):
        rows = self.db.execute(
            "SELECT original_url, short_code, created_at, clicks FROM urls "
            "WHERE user_id = ? ORDER BY id DESC LIMIT 200", (self.user_id,)).fetchall()
        fill_table(self.table, [(r["short_code"], f"{BASE_URL}/{r['short_code']}", r["original_url"],
                                 r["clicks"], r["created_at"]) for r in rows])

    def _selected_code(self):
        code = selected_text(self.table, 0)
        if code is None:
            QMessageBox.information(self, "Select a link", "Click a row in the table first.")
        return code

    def copy(self):
        code = self._selected_code()
        if code is not None:
            QGuiApplication.clipboard().setText(f"{BASE_URL}/{code}")

    def open_link(self):
        code = self._selected_code()
        if code is not None:
            QDesktopServices.openUrl(QUrl(f"{BASE_URL}/{code}"))
            QTimer.singleShot(1500, self.refresh)           # show the new click count

    def stats(self):
        code = self._selected_code()
        if code is None:
            return
        link = self.db.execute(
            "SELECT id, original_url, clicks, created_at FROM urls WHERE short_code = ? AND user_id = ?",
            (code, self.user_id)).fetchone()
        if not link:
            return
        by_day = self.db.execute(
            "SELECT date(clicked_at) AS day, COUNT(*) AS n FROM url_clicks WHERE url_id = ? "
            "GROUP BY day ORDER BY day DESC LIMIT 7", (link["id"],)).fetchall()
        recent = self.db.execute(
            "SELECT clicked_at, referrer FROM url_clicks WHERE url_id = ? ORDER BY id DESC LIMIT 10",
            (link["id"],)).fetchall()
        text = [f"Short code: {code}", f"Original: {link['original_url']}",
                f"Total clicks: {link['clicks']}", f"Created: {link['created_at']}", "",
                "Clicks per day:"]
        text += [f"  {r['day']}: {r['n']}" for r in by_day] or ["  (no clicks yet)"]
        text += ["", "Recent clicks:"]
        text += [f"  {r['clicked_at']}  {r['referrer'] or '(no referrer)'}" for r in recent] or ["  (none)"]
        QMessageBox.information(self, "Link stats", "\n".join(text))

    def delete(self):
        code = self._selected_code()
        if code is None:
            return
        if QMessageBox.question(self, "Delete link", f"Delete short link '{code}'?") != QMessageBox.Yes:
            return
        self.db.execute("DELETE FROM urls WHERE short_code = ? AND user_id = ?", (code, self.user_id))
        self.db.commit()
        self.refresh()
        self.on_change()
