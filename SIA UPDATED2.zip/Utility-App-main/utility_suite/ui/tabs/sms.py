"""3B.2  SMS & Messaging tab: real single send (Twilio), simulated bulk send, message log."""
from PySide6.QtWidgets import (QComboBox, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QPlainTextEdit, QPushButton, QVBoxLayout)

import sms_provider
from routes import messaging as msg

from ..sms_settings import SmsSettingsDialog
from ..widgets import Worker, fill_table, make_table
from .base import BaseTab


class SmsTab(BaseTab):
    def __init__(self, db, user_id, on_change, parent=None):
        super().__init__(db, user_id, on_change, parent)
        self.worker = None
        self._on_done = None

        self.mode_label = QLabel()
        settings_btn = QPushButton("SMS settings...")
        settings_btn.clicked.connect(self.open_settings)
        mode_bar = QHBoxLayout()
        mode_bar.addWidget(self.mode_label)
        mode_bar.addStretch()
        mode_bar.addWidget(settings_btn)

        self.recipient = QLineEdit()
        self.recipient.setPlaceholderText("e.g. 09171234567 or +639171234567")
        self.body = QPlainTextEdit()
        self.body.setFixedHeight(90)
        self.body.textChanged.connect(self.update_counter)
        self.counter = QLabel()
        form = QGridLayout()
        form.addWidget(QLabel("Mobile number"), 0, 0)
        form.addWidget(self.recipient, 0, 1)
        form.addWidget(QLabel("Message"), 1, 0)
        form.addWidget(self.body, 1, 1)
        form.addWidget(self.counter, 2, 1)
        form.setColumnStretch(1, 1)

        self.send_btn = QPushButton("Send")
        self.send_btn.setProperty("primary", True)
        self.send_btn.clicked.connect(self.send)
        self.bulk_btn = QPushButton(f"Bulk send (simulated) to latest {msg.BULK_LIMIT} stored contacts "
                                    "({first_name}, {last_name}, {name})")
        self.bulk_btn.clicked.connect(self.bulk)
        self.check_btn = QPushButton("Check delivery status")
        self.check_btn.clicked.connect(self.check_status)
        self.result = QLabel()
        self.result.setObjectName("muted")
        actions = QHBoxLayout()
        for button in (self.send_btn, self.bulk_btn, self.check_btn):
            actions.addWidget(button)
        actions.addWidget(self.result, 1)

        self.filter = QComboBox()
        self.filter.addItems(["all", *msg.STATUSES])
        self.filter.currentIndexChanged.connect(lambda _i: self.refresh())
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.refresh)
        log_bar = QHBoxLayout()
        log_bar.addWidget(QLabel("Message log, filter"))
        log_bar.addWidget(self.filter)
        log_bar.addWidget(refresh_btn)
        log_bar.addStretch()

        columns = [("id", "#"), ("to", "Recipient"), ("status", "Status"), ("via", "Via"), ("seg", "Parts"),
                   ("body", "Message"), ("reason", "Failure reason"), ("time", "Queued")]
        self.table = make_table(columns, [40, 120, 80, 80, 50, 280, 200, 140])

        layout = QVBoxLayout(self)
        layout.addLayout(mode_bar)
        layout.addLayout(form)
        layout.addLayout(actions)
        layout.addLayout(log_bar)
        layout.addWidget(self.table, 1)
        self.update_mode()
        self.update_counter()
        self.refresh()

    # ----- helpers -----
    def _text(self):
        return self.body.toPlainText().strip()

    def update_counter(self):
        text = self._text()
        self.counter.setText(f"{len(text)}/{msg.MAX_MESSAGE_LEN} characters, "
                             f"{msg.sms_segments(text)} SMS part(s)")

    def update_mode(self):
        live = sms_provider.is_configured()
        self.mode_label.setText("Mode: LIVE. Messages are really sent through Twilio." if live else
                                "Mode: SIMULATED. No real text is sent until you add Twilio settings.")
        self.mode_label.setStyleSheet("font-weight: 600; color: " + ("#15803d;" if live else "#a16207;"))
        self.check_btn.setEnabled(live)

    def open_settings(self):
        if SmsSettingsDialog(self).exec():
            self.update_mode()

    def _busy(self, busy, text=""):
        for button in (self.send_btn, self.bulk_btn, self.check_btn):
            button.setEnabled(not busy)
        if not busy:
            self.update_mode()                      # re-applies the check_btn rule
        if text:
            self.result.setText(text)

    def _run(self, job, on_done, working_text):
        """Run job(db) on a background thread, then call on_done(result) on the window's thread."""
        self._busy(True, working_text)
        self._on_done = on_done
        self.worker = Worker(job, self)
        # Bound methods of this widget (not lambdas), so Qt delivers the signals on the GUI thread.
        self.worker.done.connect(self._finished)
        self.worker.failed.connect(self._failed)
        self.worker.start()

    def _finished(self, result):
        self._busy(False)
        self._on_done(result)
        self.refresh()
        self.on_change()

    def _failed(self, error):
        self._busy(False, "")
        QMessageBox.critical(self, "Something went wrong", error)

    # ----- actions -----
    def send(self):
        number, text = msg.normalize_number(self.recipient.text()), self._text()
        if not number:
            QMessageBox.critical(self, "Invalid number",
                                 "Enter a valid mobile number (e.g. 09171234567 or +639171234567)")
            return
        problem = msg.validate_message(text)
        if problem:
            QMessageBox.critical(self, "Invalid message", problem)
            return
        user_id = self.user_id
        self._run(lambda db: msg.dispatch_message(db, user_id, number, text),
                  lambda res: self.result.setText(f"{number}: {res[0]}" + (f" ({res[1]})" if res[1] else "")),
                  f"Sending to {number}...")

    def bulk(self):
        template = self._text()
        problem = msg.validate_message(template)
        if problem:
            QMessageBox.critical(self, "Invalid message", problem)
            return
        contacts = msg.load_bulk_contacts(self.db, self.user_id)
        if not contacts:
            QMessageBox.information(self, "No contacts", "No stored records with a mobile number yet.\n"
                                    "Generate some first (tick the Mobile number field).")
            return
        if QMessageBox.question(
                self, "Bulk send (simulated)",
                f"Simulate sending this message to {len(contacts)} contacts?\n\n"
                "Bulk sends never use Twilio: the stored numbers are randomly generated and could "
                "belong to real people.") != QMessageBox.Yes:
            return
        user_id = self.user_id

        def job(db):
            summary = {"delivered": 0, "failed": 0, "skipped": 0}
            for contact in msg.load_bulk_contacts(db, user_id):
                number = msg.normalize_number(contact["mobile_number"])
                if not number:
                    summary["skipped"] += 1
                    continue
                body = msg.personalize(template, contact)[:msg.MAX_MESSAGE_LEN]
                status, _reason = msg.dispatch_message(db, user_id, number, body, live=False)
                summary[status] += 1
            return summary

        self._run(job, lambda s: self.result.setText("Bulk (simulated): " + ", ".join(
            f"{v} {k}" for k, v in s.items())), "Sending...")

    def check_status(self):
        user_id = self.user_id
        self._run(lambda db: msg.refresh_statuses(db, user_id),
                  lambda n: self.result.setText(f"{n} message(s) updated"), "Checking with Twilio...")

    def refresh(self):
        query = ("SELECT id, recipient, message_body, segments, status, failure_reason, queued_at, provider "
                 "FROM message_logs WHERE user_id = ?")
        params = [self.user_id]
        if self.filter.currentText() != "all":
            query += " AND status = ?"
            params.append(self.filter.currentText())
        rows = self.db.execute(query + " ORDER BY id DESC LIMIT 100", params).fetchall()
        fill_table(self.table, [(r["id"], r["recipient"], r["status"], r["provider"], r["segments"],
                                 r["message_body"], r["failure_reason"] or "", r["queued_at"])
                                for r in rows])

    def shutdown(self):
        if self.worker is not None and self.worker.isRunning():
            self.worker.wait(30000)                 # let a send in progress finish and be logged
