"""Login and registration screen. Passwords are checked with security.py (PBKDF2 + salt)."""
import sqlite3

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout, QWidget)

from routes.auth import MAX_PASSWORD_LENGTH, MIN_PASSWORD_LENGTH, USERNAME_RE
from security import DUMMY_HASH, hash_password, verify_password


class LoginWidget(QWidget):
    def __init__(self, db, on_success, parent=None):
        super().__init__(parent)
        self.db, self.on_success = db, on_success

        title = QLabel("Utility Suite")
        title.setObjectName("title")
        title.setAlignment(Qt.AlignCenter)
        subtitle = QLabel("Log in or create an account")
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setObjectName("muted")

        self.user_entry = QLineEdit()
        self.user_entry.setPlaceholderText("Username")
        self.pw_entry = QLineEdit()
        self.pw_entry.setPlaceholderText("Password")
        self.pw_entry.setEchoMode(QLineEdit.Password)
        for entry in (self.user_entry, self.pw_entry):
            entry.setFixedWidth(280)
            entry.returnPressed.connect(self.login)

        login_btn, register_btn = QPushButton("Log in"), QPushButton("Register")
        login_btn.setProperty("primary", True)
        login_btn.clicked.connect(self.login)
        register_btn.clicked.connect(self.register)
        buttons = QHBoxLayout()
        buttons.addStretch()
        buttons.addWidget(login_btn)
        buttons.addWidget(register_btn)
        buttons.addStretch()

        self.error = QLabel("")
        self.error.setObjectName("error")
        self.error.setWordWrap(True)
        self.error.setAlignment(Qt.AlignCenter)
        self.error.setFixedWidth(320)

        layout = QVBoxLayout(self)
        layout.addStretch()
        for widget in (title, subtitle):
            layout.addWidget(widget)
        layout.addSpacing(12)
        layout.addWidget(self.user_entry, alignment=Qt.AlignCenter)
        layout.addWidget(self.pw_entry, alignment=Qt.AlignCenter)
        layout.addLayout(buttons)
        layout.addWidget(self.error, alignment=Qt.AlignCenter)
        layout.addStretch()
        self.user_entry.setFocus()

    def _credentials(self):
        return self.user_entry.text().strip(), self.pw_entry.text()

    def login(self):
        username, password = self._credentials()
        user = self.db.execute(
            "SELECT id, username, password_hash FROM users WHERE username = ?", (username,)).fetchone()
        # Always verify a hash, even for unknown users, so timing does not reveal which names exist.
        stored = user["password_hash"] if user else DUMMY_HASH
        if not (verify_password(password, stored) and user):
            self.error.setText("Invalid username or password")
            return
        self.on_success(user["id"], user["username"])

    def register(self):
        username, password = self._credentials()
        if not USERNAME_RE.fullmatch(username):
            self.error.setText("Username must be 3-30 characters: letters, numbers, underscore")
            return
        if not MIN_PASSWORD_LENGTH <= len(password) <= MAX_PASSWORD_LENGTH:
            self.error.setText(f"Password must be {MIN_PASSWORD_LENGTH}-{MAX_PASSWORD_LENGTH} characters")
            return
        try:
            cur = self.db.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)",
                                  (username, hash_password(password)))
            self.db.commit()
        except sqlite3.IntegrityError:
            self.db.rollback()              # release the write lock the failed insert left open
            self.error.setText("Username is already taken")
            return
        self.on_success(cur.lastrowid, username)
