"""Real SMS delivery through Twilio's REST API (standard library only, no extra package).

Credentials come from environment variables or from `sms_settings.json` (written by the GUI's
"SMS settings" dialog). Environment variables win. Nothing is sent for real until all of these exist:

    TWILIO_ACCOUNT_SID           starts with AC...
    TWILIO_AUTH_TOKEN
    TWILIO_FROM_NUMBER           your Twilio number in +E.164 form
        or
    TWILIO_MESSAGING_SERVICE_SID starts with MG... (used instead of a from-number)

Without them the app keeps using the simulator in routes/messaging.py.
To use another provider, replace `send_sms()` and `fetch_status()`; they return a SendResult.
"""
import base64
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass

from config import BASE_DIR

SETTINGS_FILE = os.path.join(BASE_DIR, "sms_settings.json")
TIMEOUT_SECONDS = 15

KEYS = ("account_sid", "auth_token", "from_number", "messaging_service_sid")
ENV_NAMES = {
    "account_sid": "TWILIO_ACCOUNT_SID",
    "auth_token": "TWILIO_AUTH_TOKEN",
    "from_number": "TWILIO_FROM_NUMBER",
    "messaging_service_sid": "TWILIO_MESSAGING_SERVICE_SID",
}

# Twilio message status -> the app's four statuses (queued, sent, delivered, failed).
# "queued/accepted/sending/sent" only mean the carrier network has the message, not the phone.
STATUS_MAP = {
    "accepted": "sent", "scheduled": "sent", "queued": "sent", "sending": "sent", "sent": "sent",
    "delivered": "delivered",
    "failed": "failed", "undelivered": "failed", "canceled": "failed",
}


@dataclass
class SendResult:
    status: str                     # sent / delivered / failed
    reason: str = None              # failure text, if any
    provider_id: str = None         # Twilio message SID (SM...), used to look the status up later


# ---------- settings ----------
def settings_path():
    return os.environ.get("SMS_SETTINGS_FILE", SETTINGS_FILE)


def _read_file():
    try:
        with open(settings_path(), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def load_settings():
    """Merged settings: file first, then environment variables on top."""
    data = _read_file()
    values = {key: str(data.get(key) or "").strip() for key in KEYS}
    for key, env_name in ENV_NAMES.items():
        if os.environ.get(env_name, "").strip():
            values[key] = os.environ[env_name].strip()
    return values


def save_settings(values):
    """Write the settings file readable by the owner only (it holds the auth token)."""
    clean = {key: str(values.get(key) or "").strip() for key in KEYS}
    fd = os.open(settings_path(), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(clean, f, indent=2)


def clear_settings():
    try:
        os.remove(settings_path())
    except FileNotFoundError:
        pass


def is_configured(settings=None):
    s = settings or load_settings()
    return bool(s["account_sid"] and s["auth_token"] and (s["from_number"] or s["messaging_service_sid"]))


# ---------- HTTP ----------
def _api_base():
    # TWILIO_API_BASE exists so the tests can point at a local fake server.
    return os.environ.get("TWILIO_API_BASE", "https://api.twilio.com").rstrip("/")


def _call(settings, method, path, form=None):
    """One Twilio API call. Returns (http_status, parsed_json). Network problems raise OSError."""
    url = f"{_api_base()}/2010-04-01/Accounts/{settings['account_sid']}/{path}"
    data = urllib.parse.urlencode(form).encode("utf-8") if form else None
    token = base64.b64encode(f"{settings['account_sid']}:{settings['auth_token']}".encode()).decode()
    req = urllib.request.Request(url, data=data, method=method,
                                 headers={"Authorization": f"Basic {token}", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            status, raw = resp.status, resp.read()
    except urllib.error.HTTPError as err:          # 4xx/5xx still carry a JSON error body
        status, raw = err.code, err.read()
    try:
        body = json.loads(raw.decode("utf-8") or "{}")
    except ValueError:
        body = {}
    return status, body


def _failure(status, body):
    code, message = body.get("code"), body.get("message")
    if status == 401:
        return "Twilio rejected the Account SID / Auth Token (check SMS settings)"
    if message:
        return f"Twilio error {code}: {message}" if code else f"Twilio error: {message}"
    return f"Twilio returned HTTP {status}"


def _result(body):
    status = STATUS_MAP.get(str(body.get("status", "")).lower(), "sent")
    reason = body.get("error_message") or None
    if status == "failed" and not reason:
        reason = f"Twilio status: {body.get('status')}"
    if body.get("error_code") and reason:
        reason = f"Twilio error {body['error_code']}: {reason}"
    return SendResult(status, reason, body.get("sid"))


# ---------- public API ----------
def send_sms(number, text):
    """Send one text through Twilio. Never raises: problems come back as a failed SendResult."""
    settings = load_settings()
    if not is_configured(settings):
        return SendResult("failed", "SMS provider is not configured")
    form = {"To": number, "Body": text}
    if settings["messaging_service_sid"]:
        form["MessagingServiceSid"] = settings["messaging_service_sid"]
    else:
        form["From"] = settings["from_number"]
    try:
        status, body = _call(settings, "POST", "Messages.json", form)
    except OSError as err:                          # DNS, refused, timeout, TLS...
        return SendResult("failed", f"Network error: {err}")
    if status not in (200, 201):
        return SendResult("failed", _failure(status, body))
    return _result(body)


def fetch_status(provider_id):
    """Ask Twilio where a message is now. Returns None if the lookup itself did not work."""
    settings = load_settings()
    if not is_configured(settings):
        return None
    try:
        status, body = _call(settings, "GET", f"Messages/{urllib.parse.quote(provider_id)}.json")
    except OSError:
        return None
    return _result(body) if status == 200 else None
