"""3B.2  SMS & messaging dispatcher.

Single sends go out for real through Twilio when credentials are set (see sms_provider.py);
otherwise they use the simulator. Bulk sends to the generated fake contacts are ALWAYS simulated:
those numbers are random and could belong to real people.
"""
import math
import random
import re

from flask import Blueprint, jsonify, request

import sms_provider
from database import get_db
from helpers import api_error, current_user_id, json_body, login_required

bp = Blueprint("messaging", __name__)

MAX_MESSAGE_LEN = 640
STATUSES = ("queued", "sent", "delivered", "failed")
BULK_LIMIT = 50
FAILURE_RATE = 0.10

# Phone Messaging
def normalize_number(raw):
    """Return the number in +E.164 form, or None if it is not a plausible mobile number."""
    s = re.sub(r"[\s\-().]", "", str(raw or ""))
    if re.fullmatch(r"09\d{9}", s):
        return "+63" + s[1:]
    if re.fullmatch(r"639\d{9}", s):
        return "+" + s
    if re.fullmatch(r"\+\d{8,15}", s):
        return s
    return None


def sms_segments(text):
    """One SMS holds 160 characters; longer messages are split into 153-character parts."""
    return 1 if len(text) <= 160 else math.ceil(len(text) / 153)


def validate_message(text):
    """Return an error message, or None if the text is acceptable."""
    if not text:
        return "Message cannot be empty"
    if len(text) > MAX_MESSAGE_LEN:
        return f"Message is limited to {MAX_MESSAGE_LEN} characters"
    return None


def personalize(template, contact):
    """Fill in {first_name}, {last_name} and {name}.

    Plain replace (not str.format), so user text can never break or probe the template.
    """
    first, last = contact["first_name"] or "", contact["last_name"] or ""     # fields can be unpicked
    return (template.replace("{first_name}", first)
                    .replace("{last_name}", last)
                    .replace("{name}", f"{first} {last}".strip()))

# Sending
def simulate_carrier(number):
    """Stand-in for a real provider (e.g. Twilio). Used when no real SMS provider is configured."""
    if number.endswith("0000"):
        return "failed", "Simulated carrier rejection"
    if random.random() < FAILURE_RATE:
        return "failed", "Simulated network timeout"
    return "delivered", None


def load_bulk_contacts(db, user_id):
    """The latest stored records that have a mobile number (the only field a message needs).

    Records generated without the Mobile number field cannot be messaged, so they are left out.
    """
    return db.execute(
        "SELECT first_name, last_name, mobile_number FROM fake_records "
        "WHERE user_id = ? AND mobile_number IS NOT NULL "
        f"ORDER BY id DESC LIMIT {BULK_LIMIT}", (user_id,)).fetchall()


def dispatch_message(db, user_id, number, body, live=True):
    """Send one message and log it. Returns (status, failure_reason).

    live=True and Twilio configured -> a real text; the log row stores the Twilio SID.
    Otherwise -> the simulator, with queued -> sent -> delivered/failed timestamps.
    """
    segments = sms_segments(body)
    if live and sms_provider.is_configured():
        cur = db.execute(
            "INSERT INTO message_logs (user_id, recipient, message_body, segments, status, provider) "
            "VALUES (?, ?, ?, ?, 'queued', 'twilio')", (user_id, number, body, segments))
        message_id = cur.lastrowid
        db.commit()            # free the write lock: the network call below can take seconds
        result = sms_provider.send_sms(number, body)
        db.execute(
            "UPDATE message_logs SET status = ?, failure_reason = ?, provider_id = ?, "
            "sent_at = CASE WHEN ? = 'failed' THEN NULL ELSE CURRENT_TIMESTAMP END, "
            "finished_at = CASE WHEN ? = 'sent' THEN NULL ELSE CURRENT_TIMESTAMP END WHERE id = ?",
            (result.status, result.reason, result.provider_id, result.status, result.status, message_id))
        return result.status, result.reason

    cur = db.execute(
        "INSERT INTO message_logs (user_id, recipient, message_body, segments, status) "
        "VALUES (?, ?, ?, ?, 'queued')", (user_id, number, body, segments))
    message_id = cur.lastrowid

    db.execute("UPDATE message_logs SET status = 'sent', sent_at = CURRENT_TIMESTAMP WHERE id = ?",
               (message_id,))
    status, reason = simulate_carrier(number)
    db.execute("UPDATE message_logs SET status = ?, failure_reason = ?, "
               "finished_at = CURRENT_TIMESTAMP WHERE id = ?", (status, reason, message_id))
    return status, reason


def refresh_statuses(db, user_id):
    """Ask Twilio about this user's real messages that are still 'sent'. Returns how many changed."""
    rows = db.execute(
        "SELECT id, provider_id FROM message_logs WHERE user_id = ? AND provider = 'twilio' "
        "AND status IN ('queued', 'sent') AND provider_id IS NOT NULL ORDER BY id DESC LIMIT 50",
        (user_id,)).fetchall()
    changed = 0
    for row in rows:
        result = sms_provider.fetch_status(row["provider_id"])
        if result is None or result.status == "sent":
            continue
        db.execute("UPDATE message_logs SET status = ?, failure_reason = ?, "
                   "finished_at = CURRENT_TIMESTAMP WHERE id = ?",
                   (result.status, result.reason, row["id"]))
        changed += 1
    db.commit()
    return changed


# Route
@bp.post("/api/messages/send")
@login_required
def send_message():
    data = json_body()
    number = normalize_number(data.get("recipient"))
    body = str(data.get("message") or "").strip()

    if not number:
        return api_error("Enter a valid mobile number (e.g. 09171234567 or +639171234567)", 400)
    problem = validate_message(body)
    if problem:
        return api_error(problem, 400)

    db = get_db()
    status, reason = dispatch_message(db, current_user_id(), number, body)
    db.commit()
    return jsonify(success=True, recipient=number, status=status, failure_reason=reason,
                   segments=sms_segments(body),
                   provider="twilio" if sms_provider.is_configured() else "simulated"), 201


@bp.post("/api/messages/bulk")
@login_required
def bulk_send():
    """Send a template to the mobile numbers of the stored fake records."""
    template = str(json_body().get("message") or "").strip()
    problem = validate_message(template)
    if problem:
        return api_error(problem, 400)

    db, user_id = get_db(), current_user_id()
    contacts = load_bulk_contacts(db, user_id)
    if not contacts:
        return api_error("No stored records with a mobile number yet. "
                         "Generate some first (tick the Mobile number field).", 400)

    summary = {"attempted": 0, "delivered": 0, "failed": 0, "skipped": 0}
    for contact in contacts:
        number = normalize_number(contact["mobile_number"])
        if not number:
            summary["skipped"] += 1
            continue
        body = personalize(template, contact)[:MAX_MESSAGE_LEN]
        status, _reason = dispatch_message(db, user_id, number, body, live=False)
        summary["attempted"] += 1
        summary[status] += 1
    db.commit()
    return jsonify(success=True, **summary), 201


@bp.post("/api/messages/refresh")
@login_required
def refresh_message_statuses():
    """Update 'sent' messages with Twilio's latest delivery status."""
    if not sms_provider.is_configured():
        return api_error("Real SMS is not configured", 400)
    return jsonify(success=True, updated=refresh_statuses(get_db(), current_user_id()))


@bp.get("/api/messages")
@login_required
def list_messages():
    status = request.args.get("status", "")
    if status and status not in STATUSES:
        return api_error("Invalid status filter", 400)

    query = ("SELECT id, recipient, message_body, segments, status, failure_reason, "
             "provider, queued_at, sent_at, finished_at FROM message_logs WHERE user_id = ?")
    params = [current_user_id()]
    if status:
        query += " AND status = ?"
        params.append(status)

    rows = get_db().execute(query + " ORDER BY id DESC LIMIT 100", params).fetchall()
    return jsonify(messages=[dict(r) for r in rows])